var serverConfig = {
  BASE_API: 'http://192.168.3.189:8080',
  APP_KEY: '86757125',
  APP_SECRET: 'ea1bd533d001fd73b09944f04c96a6fc'
}
